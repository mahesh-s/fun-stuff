## 1.1.1 (September 7, 2014)

* onSubmit, onInvalid handlers #51
* Ignore disabled fields #45
